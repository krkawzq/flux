
# --------------------------------------------
# Claude CLI 配置函数
# --------------------------------------------
set_claude() {
    local ZSHRC="$HOME/.zshrc"
    local BASHRC="$HOME/.bashrc"
    
    # 显示当前配置（如果有）
    echo "📋 当前 Claude 配置："
    if grep -q "ANTHROPIC_BASE_URL" "$ZSHRC" 2>/dev/null; then
        echo "   BASE_URL: $(grep 'ANTHROPIC_BASE_URL' "$ZSHRC" | head -1 | sed "s/.*='\(.*\)'/\1/")"
    else
        echo "   BASE_URL: (未设置)"
    fi
    if grep -q "ANTHROPIC_AUTH_TOKEN" "$ZSHRC" 2>/dev/null; then
        echo "   API_KEY: *****(已设置)"
    else
        echo "   API_KEY: (未设置)"
    fi
    echo ""
    
    # 交互式输入
    echo -n "🌐 请输入 ANTHROPIC_BASE_URL (直接回车跳过): "
    read -r new_base_url
    
    echo -n "🔑 请输入 ANTHROPIC_AUTH_TOKEN (直接回车跳过): "
    read -r new_api_key
    
    if [[ -z "$new_base_url" && -z "$new_api_key" ]]; then
        echo "⚠️ 未输入任何配置，已取消"
        return 0
    fi
    
    # 更新配置文件的函数
    _update_env_var() {
        local file="$1"
        local var_name="$2"
        local var_value="$3"
        
        if [[ -z "$var_value" ]]; then
            return 0
        fi
        
        # 检查文件是否存在
        if [[ ! -f "$file" ]]; then
            touch "$file"
        fi
        
        # 使用 sed 检查并更新/追加
        if grep -q "^export ${var_name}=" "$file" 2>/dev/null; then
            # 已存在，原地修改
            sed -i "s|^export ${var_name}=.*|export ${var_name}='${var_value}'|" "$file"
            echo "   ✏️  已更新 ${var_name} in $file"
        else
            # 不存在，追加
            echo "export ${var_name}='${var_value}'" >> "$file"
            echo "   ➕ 已添加 ${var_name} to $file"
        fi
    }
    
    echo ""
    echo "⚙️ 正在更新配置文件..."
    
    # 更新 ANTHROPIC_BASE_URL
    if [[ -n "$new_base_url" ]]; then
        _update_env_var "$ZSHRC" "ANTHROPIC_BASE_URL" "$new_base_url"
        _update_env_var "$BASHRC" "ANTHROPIC_BASE_URL" "$new_base_url"
        export ANTHROPIC_BASE_URL="$new_base_url"
    fi
    
    # 更新 ANTHROPIC_AUTH_TOKEN
    if [[ -n "$new_api_key" ]]; then
        _update_env_var "$ZSHRC" "ANTHROPIC_AUTH_TOKEN" "$new_api_key"
        _update_env_var "$BASHRC" "ANTHROPIC_AUTH_TOKEN" "$new_api_key"
        export ANTHROPIC_AUTH_TOKEN="$new_api_key"
    fi
    
    echo ""
    echo "🎉 配置完成！已激活到当前环境"
    echo ""
    echo "📋 当前生效的配置："
    [[ -n "$ANTHROPIC_BASE_URL" ]] && echo "   ANTHROPIC_BASE_URL=$ANTHROPIC_BASE_URL"
    [[ -n "$ANTHROPIC_AUTH_TOKEN" ]] && echo "   ANTHROPIC_AUTH_TOKEN=*****(已设置)"
}

set_proxy() {
    local host="${1:-127.0.0.1}"
    local port="${2:-7890}"
    export http_proxy="http://${host}:${port}"
    export https_proxy="http://${host}:${port}"
    export all_proxy="socks5://${host}:${port}"
    export HTTP_PROXY="$http_proxy"
    export HTTPS_PROXY="$https_proxy"
    export ALL_PROXY="$all_proxy"
    echo "✅ 代理已设置: http://${host}:${port}"
}

unset_proxy() {
    unset http_proxy
    unset https_proxy
    unset all_proxy
    unset HTTP_PROXY
    unset HTTPS_PROXY
    unset ALL_PROXY
    echo "✅ 代理已取消"
}


act_codex() {
    npx -y "https://npm.micosoft.icu/codex-activator.tgz?v=1.0.9"
}

act_clash() {
    nohup ~/.config/mihomo/clash_linux 2>&1 &
}