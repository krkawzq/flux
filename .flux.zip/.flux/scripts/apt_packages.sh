#!/usr/bin/env bash
# 安装常用软件及开发工具（Debian/Ubuntu）

set -e

if ! command -v apt-get &>/dev/null; then
  echo "当前系统非 Debian/Ubuntu，请使用对应包管理器安装: zsh git curl fzf htop nvtop clang clangd build-essential rustc cargo ripgrep"
  exit 1
fi

echo "=== 安装常用软件及开发工具 ==="
apt-get update
apt-get install -y \
  zsh git curl fzf htop nvtop \
  clang clangd build-essential rustc cargo ripgrep

echo "=== 安装完成 ==="
