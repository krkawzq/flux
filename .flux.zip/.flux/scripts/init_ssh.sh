#!/usr/bin/env bash
# 初始化 SSH 配置

set -e

SSH_DIR="${HOME}/.ssh"
PUB_KEY="${PUB_KEY:-$SSH_DIR/id_ed25519_wzq.pub}"

mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"

if [[ -f "$PUB_KEY" ]]; then
  cat "$PUB_KEY" >> "$SSH_DIR/authorized_keys"
  chmod 600 "$SSH_DIR/authorized_keys"
  echo "已将 $(basename "$PUB_KEY") 添加到 authorized_keys"
else
  echo "警告: $PUB_KEY 不存在，请先生成密钥" >&2
fi
