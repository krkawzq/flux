#!/usr/bin/env bash
# 安装 AI 编程工具：Claude Code, OpenCode, Kimi, Codex CLI
# 配置文件由 westlake.yml file sync 管理，此脚本只负责安装

set -e

alias sudo=""

# ========== Claude Code ==========
install_claude() {
  if command -v claude &>/dev/null; then
    echo "=== Claude Code 已安装，跳过 ==="
    return 0
  fi
  if ! command -v npm &>/dev/null; then
    echo "跳过 Claude Code：未检测到 npm"
    return 0
  fi
  echo "=== 安装 Claude Code ==="
  npm config set registry https://registry.npmmirror.com
  npm install -g @anthropic-ai/claude-code@latest
  echo "=== Claude Code 安装完成 ==="
}

# ========== OpenCode ==========
install_opencode() {
  if command -v opencode &>/dev/null; then
    echo "=== OpenCode 已安装，跳过 ==="
    return 0
  fi
  echo "=== 安装 OpenCode ==="
  curl -fsSL https://opencode.ai/install | bash
  # 配置目录由 file sync 创建和写入
  mkdir -p ~/.config/opencode
  mkdir -p ~/.local/share/opencode
  echo "=== OpenCode 安装完成 ==="
}

# ========== Kimi ==========
install_kimi() {
  if command -v kimi &>/dev/null; then
    echo "=== Kimi 已安装，跳过 ==="
    return 0
  fi
  echo "=== 安装 Kimi ==="
  curl -fsSL -L code.kimi.com/install.sh | bash
  echo "=== Kimi 安装完成 ==="
}

# ========== Codex CLI ==========
install_codex() {
  if command -v codex &>/dev/null; then
    echo "=== Codex CLI 已安装，跳过 ==="
    return 0
  fi
  if ! command -v npm &>/dev/null; then
    echo "跳过 Codex CLI：未检测到 npm"
    return 0
  fi
  echo "=== 安装 Codex CLI ==="
  npm install -g @openai/codex@latest
  # 配置目录由 file sync 创建和写入
  mkdir -p ~/.codex
  echo "=== Codex CLI 安装完成 ==="
}

# ========== 主流程 ==========
echo "=== 开始安装 AI 编程工具 ==="
install_claude
install_opencode
install_kimi
install_codex
echo "=== AI 编程工具安装完成 ==="
