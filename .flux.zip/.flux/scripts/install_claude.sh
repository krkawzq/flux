#!/usr/bin/env bash
# 通过 npm 全局安装 Claude Code

set -e

if ! command -v npm &>/dev/null; then
  echo "未检测到 npm，请先安装 Node.js (如运行 install_node.sh)" >&2
  exit 1
fi

echo "=== 配置 npm 镜像并安装 Claude Code ==="
npm config set registry https://registry.npmmirror.com
npm install -g @anthropic-ai/claude-code
echo "=== 安装完成 ==="
