#!/usr/bin/env bash
# 安装常用 Language Server：pyright, clangd, bash-language-server, lua-language-server 等

set -e

LSP_BIN_DIR="${LSP_BIN_DIR:-$HOME/.local/bin}"
mkdir -p "$LSP_BIN_DIR"
export PATH="$LSP_BIN_DIR:$PATH"

# --- 检测命令是否存在 ---
cmd_exists() { command -v "$1" &>/dev/null; }

# --- 通过 npm 安装 (需先有 Node/npm) ---
install_npm_lsps() {
  if ! cmd_exists npm; then
    echo "跳过 npm 类 LSP：未检测到 npm，请先安装 Node.js (如运行 install_node.sh)"
    return 0
  fi

  echo "=== 通过 npm 安装 Language Servers ==="
  npm install -g pyright                    # Python
  npm install -g bash-language-server      # Bash
  npm install -g typescript-language-server typescript  # TypeScript/JavaScript
  npm install -g vscode-langservers-extracted  # HTML/CSS/JSON (可选)
  echo "npm 类 LSP 安装完成"
}

# --- 安装 clangd (C/C++) ---
install_clangd() {
  if cmd_exists clangd; then
    echo "clangd 已安装: $(clangd --version 2>/dev/null | head -1)"
    return 0
  fi

  echo "=== 安装 clangd ==="
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if cmd_exists apt-get; then
      apt-get update
      apt-get install -y clangd
    elif cmd_exists dnf; then
      dnf install -y clang-tools-extra
    else
      echo "请手动安装 clangd: https://clangd.llvm.org/installation"
      return 1
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    if cmd_exists brew; then
      brew install llvm  # 提供 clangd
      echo "请将 $(brew --prefix llvm)/bin 加入 PATH 以使用 clangd"
    else
      echo "请安装 Homebrew 后执行: brew install llvm"
      return 1
    fi
  else
    echo "当前系统未配置自动安装 clangd，请从 https://github.com/clangd/clangd/releases 下载"
    return 1
  fi
  echo "clangd 安装完成"
}

# --- 安装 lua-language-server ---
install_lua_lsp() {
  local version="${LUA_LSP_VERSION:-3.6.5}"
  local dir="$HOME/.local/share/lua-language-server"
  local bin="$LSP_BIN_DIR/lua-language-server"

  if [[ -x "$dir/bin/lua-language-server" ]]; then
    echo "lua-language-server 已安装于 $dir"
    return 0
  fi

  echo "=== 安装 lua-language-server ==="
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    local arch
    arch=$(uname -m)
    case "$arch" in
      x86_64) arch="linux-x64" ;;
      aarch64|arm64) arch="linux-arm64" ;;
      *) echo "不支持的架构: $arch"; return 1 ;;
    esac
    local url="https://github.com/LuaLS/lua-language-server/releases/download/${version}/lua-language-server-${version}-${arch}.tar.gz"
    mkdir -p "$dir"
    curl -fsSL "$url" | tar -xzf - -C "$dir" --strip-components=1
    ln -sf "$dir/bin/lua-language-server" "$bin"
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    local arch
    arch=$(uname -m)
    case "$arch" in
      x86_64) arch="darwin-x64" ;;
      arm64) arch="darwin-arm64" ;;
      *) echo "不支持的架构: $arch"; return 1 ;;
    esac
    local url="https://github.com/LuaLS/lua-language-server/releases/download/${version}/lua-language-server-${version}-${arch}.tar.gz"
    mkdir -p "$dir"
    curl -fsSL "$url" | tar -xzf - -C "$dir" --strip-components=1
    ln -sf "$dir/bin/lua-language-server" "$bin"
  else
    echo "请从 https://github.com/LuaLS/lua-language-server/releases 手动下载 lua-language-server"
    return 1
  fi
  echo "lua-language-server 安装完成 -> $bin"
}

# --- 安装 rust-analyzer (Rust，可选) ---
install_rust_analyzer() {
  if cmd_exists rust-analyzer; then
    echo "rust-analyzer 已安装"
    return 0
  fi
  if ! cmd_exists cargo; then
    echo "跳过 rust-analyzer：未检测到 cargo"
    return 0
  fi
  echo "=== 安装 rust-analyzer ==="
  cargo install rust-analyzer
  echo "rust-analyzer 安装完成"
}

# --- 主流程 ---
main() {
  echo "=== 开始安装 Language Servers ==="
  install_npm_lsps
  install_clangd
  install_lua_lsp
  install_rust_analyzer
  echo ""
  echo "=== 安装完成 ==="
  echo "若使用 lua-language-server，请确保 $LSP_BIN_DIR 在 PATH 中，例如在 ~/.zshrc 中添加："
  echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
}

main "$@"
