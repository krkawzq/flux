#!/usr/bin/env bash
# NVM + NPM 国内镜像一键安装脚本

set -e

echo "=== 开始安装 NVM (使用国内镜像) ==="

export NVM_SOURCE=https://gitee.com/mirrors/nvm.git
curl -fsSL -o- https://gitee.com/mirrors/nvm/raw/master/install.sh | bash

export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
[[ -s "$NVM_DIR/nvm.sh" ]] && \. "$NVM_DIR/nvm.sh"

export NVM_NODEJS_ORG_MIRROR=https://npmmirror.com/mirrors/node/

echo "=== 安装 Node.js LTS 版本 ==="
nvm install --lts

echo "=== 配置 npm 淘宝镜像 ==="
npm config set registry https://registry.npmmirror.com

echo "=== 添加配置到 ~/.zshrc ==="
ZSHRC="${HOME}/.zshrc"
if [[ -f "$ZSHRC" ]] && grep -q 'NVM_DIR' "$ZSHRC" 2>/dev/null; then
  echo "NVM 配置已存在于 ~/.zshrc，跳过追加"
else
  cat >> "$ZSHRC" << 'EOF'

# NVM 配置
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
export NVM_NODEJS_ORG_MIRROR=https://npmmirror.com/mirrors/node/
EOF
fi

echo "=== 验证安装 ==="
node -v
npm -v
echo "npm 镜像源: $(npm config get registry)"
echo "=== 安装完成! ==="
echo "请运行 'source ~/.zshrc' 或重新打开终端以使配置生效"
