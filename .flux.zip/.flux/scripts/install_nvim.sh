#!/usr/bin/env bash
# 从官方 release 安装 Neovim 并克隆配置

set -e

NVIM_VERSION="${NVIM_VERSION:-latest}"
NVIM_INSTALL_DIR="${NVIM_INSTALL_DIR:-/opt}"
NVIM_CONFIG_REPO="${NVIM_CONFIG_REPO:-git@github.com:krkawzq/nvim-config.git}"

case "$(uname -s)" in
  Linux)
    case "$(uname -m)" in
      x86_64) PLATFORM="linux-x86_64" ;;
      aarch64|arm64) PLATFORM="linux-aarch64" ;;
      *) echo "不支持的架构: $(uname -m)" >&2; exit 1 ;;
    esac
    ;;
  Darwin)
    case "$(uname -m)" in
      x86_64) PLATFORM="macos-x86_64" ;;
      arm64) PLATFORM="macos-arm64" ;;
      *) echo "不支持的架构: $(uname -m)" >&2; exit 1 ;;
    esac
    ;;
  *)
    echo "不支持的系统: $(uname -s)" >&2
    exit 1
    ;;
esac

TARBALL="nvim-${PLATFORM}.tar.gz"
if [[ "$NVIM_VERSION" == "latest" ]]; then
  DOWNLOAD_URL="https://github.com/neovim/neovim/releases/latest/download/$TARBALL"
else
  DOWNLOAD_URL="https://github.com/neovim/neovim/releases/download/${NVIM_VERSION}/$TARBALL"
fi

echo "=== 下载 Neovim: $DOWNLOAD_URL ==="
curl -fsSL -o "$TARBALL" "$DOWNLOAD_URL"

NVIM_DIR_NAME="nvim-${PLATFORM}"
echo "=== 安装到 $NVIM_INSTALL_DIR ==="
sudo rm -rf "$NVIM_INSTALL_DIR/$NVIM_DIR_NAME"
sudo tar -C "$NVIM_INSTALL_DIR" -xzf "$TARBALL"
rm -f "$TARBALL"

NVIM_BIN="$NVIM_INSTALL_DIR/$NVIM_DIR_NAME/bin"
echo "=== 将 nvim 加入 PATH (写入 ~/.zshrc) ==="
ZSHRC="${HOME}/.zshrc"
if [[ -f "$ZSHRC" ]] && grep -q "$NVIM_DIR_NAME" "$ZSHRC" 2>/dev/null; then
  echo "PATH 中已包含 nvim，跳过"
else
  echo "export PATH=\"$NVIM_BIN:\$PATH\"" >> "$ZSHRC"
fi
export PATH="$NVIM_BIN:$PATH"

echo "=== 验证安装 ==="
nvim --version

echo "=== 克隆 nvim 配置 ==="
mkdir -p "${HOME}/.config"
if [[ -d "${HOME}/.config/nvim/.git" ]]; then
  echo "~/.config/nvim 已存在，跳过克隆"
else
  git clone "$NVIM_CONFIG_REPO" "${HOME}/.config/nvim"
fi
echo "=== 安装完成 ==="
