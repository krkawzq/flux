#!/usr/bin/env bash
# 安装 OpenCode (opencode.ai)

set -e

echo "=== 安装 OpenCode ==="
curl -fsSL https://opencode.ai/install | bash
echo "=== 安装完成 ==="

OPENCODE_CONFIG_SRC="${OPENCODE_CONFIG_SRC:-/zhoujingbo/wzq/opencode.json}"
OPENCODE_CONFIG_DIR="${HOME}/.config/opencode"
OPENCODE_CONFIG_DST="${OPENCODE_CONFIG_DIR}/opencode.json"

if [[ ! -f "$OPENCODE_CONFIG_SRC" ]]; then
  echo "错误: 源文件不存在: $OPENCODE_CONFIG_SRC" >&2
  echo "可通过环境变量 OPENCODE_CONFIG_SRC 指定路径" >&2
  exit 1
fi

mkdir -p "$OPENCODE_CONFIG_DIR"
cp "$OPENCODE_CONFIG_SRC" "$OPENCODE_CONFIG_DST"
echo "已复制配置到 $OPENCODE_CONFIG_DST"
