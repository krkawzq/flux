#!/usr/bin/env bash
# 从源码安装 tmux（需先安装依赖）
# 修改说明：已添加 > /dev/null 以隐藏常规输出，仅保留错误信息。

set -e

alias sudo=""

TMUX_SRC="${TMUX_SRC:-$HOME/.local/src/tmux}"
TMUX_REPO="${TMUX_REPO:-https://github.com/tmux/tmux.git}"

# --- 检测系统并安装依赖 ---
install_deps() {
  # 这里的 > /dev/null 用于隐藏包管理器的安装进度条和详细日志
  if command -v apt-get &>/dev/null; then
    echo "  -> 正在更新 apt 缓存..."
    apt-get update > /dev/null
    echo "  -> 正在安装编译依赖 (apt)..."
    apt-get install -y git automake bison build-essential pkg-config \
      libevent-dev libncurses-dev > /dev/null
  elif command -v dnf &>/dev/null; then
    echo "  -> 正在安装编译依赖 (dnf)..."
    dnf install -y git automake bison gcc make pkg-config \
      libevent-devel ncurses-devel > /dev/null
  elif command -v brew &>/dev/null; then
    echo "  -> 正在安装编译依赖 (brew)..."
    brew install libevent ncurses > /dev/null
  else
    echo "请手动安装: git, automake, bison, build-essential, pkg-config, libevent-dev, ncurses-dev"
    exit 1
  fi
}

# --- 从源码编译安装 tmux（在子 shell 内 cd，避免影响调用方 cwd）---
install_tmux_from_src() {
  echo "=== 1/4 准备环境与依赖 ==="
  install_deps

  echo "=== 2/4 获取 tmux 源码 ==="
  mkdir -p "$(dirname "$TMUX_SRC")"
  (
    if [[ -d "$TMUX_SRC/.git" ]]; then
      cd "$TMUX_SRC"
      # 使用 -q (quiet) 或重定向隐藏 git 输出
      git fetch --tags > /dev/null 2>&1
      git checkout "$(git describe --tags --abbrev=0)" > /dev/null 2>&1
    else
      # --depth 1 已经很快了，加上 -q 减少输出
      git clone --depth 1 -q "$TMUX_REPO" "$TMUX_SRC"
      cd "$TMUX_SRC"
    fi

    echo "=== 3/4 正在配置与编译 (这可能需要几分钟) ==="
    # autogen 和 configure 产生大量配置检查信息，重定向隐藏
    ./autogen.sh > /dev/null
    ./configure --prefix="${TMUX_PREFIX:-$HOME/.local}" > /dev/null

    # make 产生大量编译日志，重定向隐藏
    make -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 2)" > /dev/null
    
    echo "=== 4/4 正在安装 ==="
    make install > /dev/null
  )

  echo "=== ✅ 安装完成 ==="
  export PATH="${TMUX_PREFIX:-$HOME/.local}/bin:$PATH"
  tmux -V
}

# --- 先检查是否已有 tmux，有则跳过（除非强制重装）---
if [[ "${FORCE_TMUX_INSTALL:-0}" != "1" ]] && command -v tmux &>/dev/null; then
  echo "检测到 tmux 已安装: $(tmux -V)，跳过。设置 FORCE_TMUX_INSTALL=1 可强制从源码重装"
  exit 0
fi

# --- 没有 tmux，从源码编译安装 ---
install_tmux_from_src