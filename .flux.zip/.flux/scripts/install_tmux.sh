#!/usr/bin/env bash
# 从源码安装 tmux（需先安装依赖）

set -e

TMUX_SRC="${TMUX_SRC:-$HOME/.local/src/tmux}"
TMUX_REPO="${TMUX_REPO:-https://github.com/tmux/tmux.git}"

# --- 检测系统并安装依赖 ---
install_deps() {
  if command -v apt-get &>/dev/null; then
    apt-get update
    apt-get install -y git automake bison build-essential pkg-config \
      libevent-dev libncurses-dev
  elif command -v dnf &>/dev/null; then
    dnf install -y git automake bison gcc make pkg-config \
      libevent-devel ncurses-devel
  elif command -v brew &>/dev/null; then
    brew install libevent ncurses
  else
    echo "请手动安装: git, automake, bison, build-essential, pkg-config, libevent-dev, ncurses-dev"
    exit 1
  fi
}

# --- 从源码编译安装 tmux（在子 shell 内 cd，避免影响调用方 cwd）---
install_tmux_from_src() {
  echo "=== 安装 tmux 依赖 ==="
  install_deps

  echo "=== 克隆 tmux 源码 ==="
  mkdir -p "$(dirname "$TMUX_SRC")"
  (
    if [[ -d "$TMUX_SRC/.git" ]]; then
      cd "$TMUX_SRC"
      git fetch --tags
      git checkout "$(git describe --tags --abbrev=0)"
    else
      git clone --depth 1 "$TMUX_REPO" "$TMUX_SRC"
      cd "$TMUX_SRC"
    fi
    echo "=== 编译安装 tmux ==="
    ./autogen.sh
    ./configure --prefix="${TMUX_PREFIX:-$HOME/.local}"
    make -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 2)"
    make install
  )

  echo "=== 安装完成 ==="
  export PATH="${TMUX_PREFIX:-$HOME/.local}/bin:$PATH"
  tmux -V
}

# --- 先检查是否已有 tmux，有则跳过（除非强制重装）---
if [[ "${FORCE_TMUX_INSTALL:-0}" != "1" ]] && command -v tmux &>/dev/null; then
  echo "检测到 tmux 已安装: $(tmux -V)，跳过。设置 FORCE_TMUX_INSTALL=1 可强制从源码重装"
  exit 0
fi

# --- 没有 tmux，从源码编译安装 ---
install_tmux_from_src
