#!/usr/bin/env bash
# 安装 uv (Python 包/项目管理工具)

set -e

if command -v uv &>/dev/null; then
  echo "uv 已安装: $(uv --version 2>/dev/null || true)"
  exit 0
fi

echo "=== 安装 uv ==="
curl -fsSL https://astral.sh/uv/install.sh | sh

UV_ENV="${HOME}/.local/bin/env"
if [[ -f "$UV_ENV" ]]; then
  set +e
  # shellcheck source=/dev/null
  . "$UV_ENV"
  set -e
fi
echo "=== 安装完成 ==="
