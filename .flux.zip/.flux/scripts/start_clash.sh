#!/usr/bin/env bash
# 启动 Clash 代理服务（后台运行）

set -e

alias sudo=""

CLASH_BIN="$HOME/.config/mihomo/clash-linux"
CLASH_LOG="$HOME/.config/mihomo/clash.log"
CLASH_PID_FILE="$HOME/.config/mihomo/clash.pid"

# ========== 检测 clash-linux 是否存在 ==========
if [[ ! -x "$CLASH_BIN" ]]; then
  echo "错误: clash-linux 不存在或不可执行: $CLASH_BIN"
  exit 1
fi

# ========== 检测是否已在运行 ==========
if [[ -f "$CLASH_PID_FILE" ]]; then
  OLD_PID=$(cat "$CLASH_PID_FILE")
  if ps -p "$OLD_PID" &>/dev/null; then
    echo "=== Clash 已在运行 (PID: $OLD_PID)，跳过 ==="
    exit 0
  else
    echo "检测到旧 PID 文件但进程不存在，清理后重新启动"
    rm -f "$CLASH_PID_FILE"
  fi
fi

# ========== 启动 Clash ==========
echo "=== 启动 Clash 代理服务 ==="
mkdir -p "$(dirname "$CLASH_LOG")"

nohup "$CLASH_BIN" >> "$CLASH_LOG" 2>&1 &
CLASH_PID=$!

# 保存 PID
echo "$CLASH_PID" > "$CLASH_PID_FILE"

# 等待 1 秒检测是否启动成功
sleep 1
if ps -p "$CLASH_PID" &>/dev/null; then
  echo "=== Clash 启动成功 (PID: $CLASH_PID) ==="
  echo "日志文件: $CLASH_LOG"
else
  echo "错误: Clash 启动失败，请查看日志: $CLASH_LOG"
  rm -f "$CLASH_PID_FILE"
  exit 1
fi
