#!/usr/bin/env bash
# 安装常用软件及开发工具（Debian/Ubuntu）。幂等。

set -e

alias sudo=""

if ! command -v apt-get &>/dev/null; then
  echo "当前系统非 Debian/Ubuntu，请使用对应包管理器安装"
  exit 1
fi

PACKAGES=(
  zsh git curl fzf htop nvtop
  clang clangd build-essential ripgrep gh
)

MISSING=()
for pkg in "${PACKAGES[@]}"; do
  if ! dpkg -s "$pkg" &>/dev/null; then
    MISSING+=("$pkg")
  fi
done

if [[ ${#MISSING[@]} -eq 0 ]]; then
  echo "=== 所有 apt 包已安装，跳过 ==="
else
  echo "=== 需要安装: ${MISSING[*]} ==="
  apt-get update
  apt-get install -y "${MISSING[@]}"
  echo "=== apt 安装完成 ==="
fi

# cloc 单独安装到 /usr/local/bin（不用 apt 的旧版本）
if [[ -x /usr/local/bin/cloc ]]; then
  echo "=== cloc 已存在: $(/usr/local/bin/cloc --version 2>/dev/null | head -1)，跳过 ==="
else
  echo "=== 下载 cloc ==="
  sudo curl -fsSL https://raw.githubusercontent.com/AlDanial/cloc/master/cloc -o /usr/local/bin/cloc
  sudo chmod +x /usr/local/bin/cloc
fi
