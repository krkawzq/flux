#!/usr/bin/env bash
# 配置 GitHub SSH 与 git 用户信息。幂等：
# - SSH Host 块已正确则跳过；不正确则原位覆盖
# - git user.name / user.email 已正确则跳过

set -e

alias sudo=""

SSH_DIR="${HOME}/.ssh"
IDENTITY_FILE="${IDENTITY_FILE:-$SSH_DIR/id_ed25519_wzq}"
GIT_USER_NAME="${GIT_USER_NAME:-wzq}"
GIT_USER_EMAIL="${GIT_USER_EMAIL:-2868116803@qq.com}"

mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"
touch "$SSH_DIR/config"
chmod 600 "$SSH_DIR/config"

# ---- GitHub Host 块 ----
expected_block=$(cat <<EOF
Host github.com
    HostName github.com
    User git
    IdentityFile $IDENTITY_FILE
    IdentitiesOnly yes
EOF
)

current_block=$(awk '
  /^Host github\.com$/ { in_blk=1; print; next }
  in_blk && /^Host[[:space:]]/ { in_blk=0 }
  in_blk { print }
' "$SSH_DIR/config")

if [[ "$current_block" == "$expected_block" ]]; then
  echo "=== GitHub SSH Host 块已是最新，跳过 ==="
else
  echo "=== 更新 GitHub SSH Host 块 ==="
  # 删除旧的 github.com Host 块（直到下一个 Host 或文件结尾）
  awk '
    /^Host github\.com$/ { skip=1; next }
    skip && /^Host[[:space:]]/ { skip=0 }
    !skip { print }
  ' "$SSH_DIR/config" > "$SSH_DIR/config.tmp"
  mv "$SSH_DIR/config.tmp" "$SSH_DIR/config"
  printf '\n%s\n' "$expected_block" >> "$SSH_DIR/config"
  chmod 600 "$SSH_DIR/config"
fi

# ---- 首次 known_hosts 探测，跳过 strict host key check 等待 ----
if ! ssh-keygen -F github.com >/dev/null 2>&1; then
  echo "=== 把 github.com host key 加入 known_hosts ==="
  ssh-keyscan -H github.com >> "$SSH_DIR/known_hosts" 2>/dev/null || true
  chmod 600 "$SSH_DIR/known_hosts"
fi

# ---- git user.name / user.email ----
if [[ "$(git config --global user.name 2>/dev/null)" != "$GIT_USER_NAME" ]]; then
  git config --global user.name "$GIT_USER_NAME"
  echo "  git user.name = $GIT_USER_NAME"
fi
if [[ "$(git config --global user.email 2>/dev/null)" != "$GIT_USER_EMAIL" ]]; then
  git config --global user.email "$GIT_USER_EMAIL"
  echo "  git user.email = $GIT_USER_EMAIL"
fi

echo "=== GitHub 配置完成 ==="
