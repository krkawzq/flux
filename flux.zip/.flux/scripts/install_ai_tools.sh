#!/usr/bin/env bash
# AI 编程工具 + Claude 插件安装。
#
# 设计原则：
#   - npm install -g <pkg>@latest 不加跳过 — 总尝试更新（已是最新 npm 自己会秒过）
#   - Claude 插件用 `claude plugin list --json` 探测，已装才跳过
#   - 系统级 ln/mkdir 自身幂等

set -e

alias sudo=""

echo "=== 开始安装 AI 编程工具 ==="

if ! command -v npm &>/dev/null; then
  echo "错误：未检测到 npm，无法安装 npm 包"
  exit 1
fi

# ========== npm 代理 ==========
echo "=== 配置 npm 代理：HTTP 7890 ==="
export HTTP_PROXY="http://127.0.0.1:7890"
export HTTPS_PROXY="http://127.0.0.1:7890"
export http_proxy="http://127.0.0.1:7890"
export https_proxy="http://127.0.0.1:7890"
npm config set proxy "http://127.0.0.1:7890"
npm config set https-proxy "http://127.0.0.1:7890"
npm config set registry "https://registry.npmjs.org/"

# ========== npm install helper：官方失败回退淘宝镜像 ==========
npm_install_latest() {
  local pkg="$1"
  echo "=== npm install -g $pkg ==="
  if npm install -g "$pkg"; then
    return 0
  fi
  echo "  官方 registry 失败，回退淘宝镜像"
  npm config set registry "https://registry.npmmirror.com"
  npm install -g "$pkg"
  npm config set registry "https://registry.npmjs.org/"
}

# ---------- @latest npm 包：全部 always-run（user 明确要求）----------
npm_install_latest "@anthropic-ai/claude-code@latest"
npm_install_latest "opencode-ai@latest"
mkdir -p "$HOME/.config/opencode" "$HOME/.local/share/opencode"

# codex CLI: 避免和老 /usr/local/bin/codex 二进制冲突
rm -f /usr/local/bin/codex 2>/dev/null || true
npm_install_latest "@openai/codex@latest"
mkdir -p "$HOME/.codex"

# codex auth.json 软链接（指向共享配置）— 幂等：已是同一链接就跳过
CODEX_AUTH="$HOME/.codex/auth.json"
CODEX_AUTH_SRC="/zhoujingbo/wzq/codex_auth.json"
if [[ -L "$CODEX_AUTH" && "$(readlink "$CODEX_AUTH")" == "$CODEX_AUTH_SRC" ]]; then
  echo "=== codex auth.json 软链已正确，跳过 ==="
else
  rm -f "$CODEX_AUTH"
  ln -s "$CODEX_AUTH_SRC" "$CODEX_AUTH"
  echo "=== codex auth.json → $CODEX_AUTH_SRC ==="
fi

npm_install_latest "@fission-ai/openspec@latest"
npm_install_latest "uipro-cli@latest"
npm_install_latest "ccusage@latest"

# ========== Claude 插件 ==========
if ! command -v claude &>/dev/null; then
  echo "警告：未检测到 claude 命令，跳过 Claude 插件安装"
else
  echo "=== Claude 插件 ==="

  # marketplace add 本身幂等
  claude plugin marketplace add anthropics/claude-plugins-official 2>/dev/null || true
  claude plugin marketplace add jarrodwatts/claude-hud 2>/dev/null || true
  claude plugin marketplace add openai/codex-plugin-cc 2>/dev/null || true
  claude plugin marketplace add krkawzq/cc-codex-team 2>/dev/null || true

  # 获取已装插件 id 列表（去掉 @marketplace 后缀）
  INSTALLED_PLUGINS=""
  if claude plugin list --json >/dev/null 2>&1; then
    if command -v jq &>/dev/null; then
      INSTALLED_PLUGINS=$(claude plugin list --json 2>/dev/null | jq -r '.[].id' | cut -d'@' -f1 | sort -u)
    else
      # 无 jq 兜底：grep 出 "id": "xxx@..."
      INSTALLED_PLUGINS=$(claude plugin list --json 2>/dev/null \
        | grep -oE '"id":[[:space:]]*"[^"@]+' \
        | sed 's/.*"//' | sort -u)
    fi
  fi

  install_plugin() {
    local plugin="$1"
    # plugin 可能是 "name" 或 "name@marketplace"；取前半段做匹配
    local plugin_name="${plugin%%@*}"
    if echo "$INSTALLED_PLUGINS" | grep -qx "$plugin_name"; then
      echo "  $plugin_name 已安装，跳过"
      return 0
    fi
    echo "  安装 $plugin"
    claude plugin install "$plugin" || echo "  ⚠ $plugin 安装失败，继续下一个"
  }

  install_plugin claude-hud
  install_plugin pyright-lsp
  install_plugin clangd-lsp
  install_plugin rust-analyzer-lsp
  install_plugin code-review
  install_plugin github
  install_plugin context7
  install_plugin frontend-design
  install_plugin skill-creator
  install_plugin huggingface-skills
  install_plugin superpowers
  install_plugin code-simplifier
  install_plugin chrome-devtools-mcp
  install_plugin feature-dev
  install_plugin typescript-lsp
  install_plugin codex@openai-codex
  install_plugin codex-team
fi

# 恢复官方 registry
npm config set registry "https://registry.npmjs.org/"
echo "=== AI 编程工具完成 ==="
