#!/usr/bin/env bash
# 安装和配置 zsh (oh-my-zsh + Powerlevel10k + 插件)。幂等。

set -e

alias sudo=""

export RUNZSH=no
export CHSH=no
export KEEP_ZSHRC=yes

ZSH_CUSTOM="${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}"

if [[ -d "$HOME/.oh-my-zsh" ]]; then
  echo "=== oh-my-zsh 已安装，跳过 ==="
else
  echo "=== 安装 oh-my-zsh ==="
  sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
fi

if [[ -d "$ZSH_CUSTOM/themes/powerlevel10k" ]]; then
  echo "=== Powerlevel10k 已安装，跳过 ==="
else
  echo "=== 安装 Powerlevel10k ==="
  git clone --depth=1 https://github.com/romkatv/powerlevel10k.git \
    "$ZSH_CUSTOM/themes/powerlevel10k"
fi

for repo in \
  "zsh-users/zsh-completions:plugins/zsh-completions" \
  "zsh-users/zsh-syntax-highlighting:plugins/zsh-syntax-highlighting" \
  "zsh-users/zsh-autosuggestions:plugins/zsh-autosuggestions"; do
  name="${repo%%:*}"
  path="$ZSH_CUSTOM/${repo#*:}"
  if [[ -d "$path" ]]; then
    echo "  $name 已安装，跳过"
  else
    echo "  克隆 $name"
    git clone --depth=1 "https://github.com/$name.git" "$path"
  fi
done

# 默认 shell（chsh 仅在当前不是 zsh 时执行）
ZSH_BIN="$(command -v zsh || true)"
if [[ -n "$ZSH_BIN" && "$SHELL" != "$ZSH_BIN" ]]; then
  echo "=== 设置 zsh 为默认 shell ==="
  chsh -s "$ZSH_BIN" || echo "警告: chsh 失败，请手动执行 chsh -s $ZSH_BIN" >&2
else
  echo "=== 默认 shell 已是 zsh，跳过 chsh ==="
fi

# conda init zsh 仅在装了 conda 且 .zshrc 还没初始化时跑
if command -v conda &>/dev/null; then
  if [[ -f "$HOME/.zshrc" ]] && grep -q "conda initialize" "$HOME/.zshrc"; then
    echo "=== conda zsh 已初始化，跳过 ==="
  else
    echo "=== conda init zsh ==="
    conda init zsh
  fi
else
  echo "=== conda 未安装，跳过 conda init ==="
fi

echo "=== zsh 配置完成 ==="
