#!/bin/bash
# 启动 VPN (mihomo) 后台 session。幂等：已运行则不再启动。

set -e

SESSION="vpn"

if ! command -v tmux &>/dev/null; then
  echo "未安装 tmux，跳过 VPN 启动"
  exit 0
fi

if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "=== tmux session '$SESSION' 已在运行，跳过 ==="
  exit 0
fi

echo "=== 启动 VPN tmux session '$SESSION' ==="
tmux new-session -d -s "$SESSION" \
  'bash /zhoujingbo/wzq/mihomo/start.sh && tail -f /zhoujingbo/wzq/mihomo/clash.log'
echo "=== VPN 已启动（tmux attach -t $SESSION 查看日志）==="
